# Handoff: Testquest UI Revamp — Meridian Direction

## Overview
This is a full UI revamp for **Testquest**, an edtech platform for Indian school students (Class 6–12) to take timed test series. The rebuild targets CBSE, ICSE, and State Board students.

The chosen design direction is **Meridian** — a premium dark-mode aesthetic with saffron gold accents. It feels like a prestigious coaching institution, modernised. This was selected from 3 explored directions (see `Testquest Revamp.html` for all 3).

---

## About the Design Files

The `.html` files in this bundle are **design references built as HTML prototypes** — they show the intended look, layout, animations, and interactions. They are **not production code** to copy directly.

Your task is to **recreate these designs in the existing Testquest codebase** (Next.js 15, App Router, Tailwind CSS v4, TypeScript). Use the established patterns, component library (`src/components/ui/`), and Tailwind token system — applying the new design tokens and layout structures documented here.

**Fidelity: High-fidelity.** These prototypes are pixel-close to the intended final UI. Recreate layout, spacing, colors, typography, and animations faithfully.

---

## Target Codebase

- **Framework:** Next.js 15 (App Router, `src/` directory)
- **Styling:** Tailwind CSS v4
- **Language:** TypeScript
- **Fonts:** DM Serif Display + DM Sans (replace current Geist Sans + Instrument Serif)
- **Components:** Shadcn/ui base components in `src/components/ui/`

---

## Design Tokens

### Colors (add to `src/app/globals.css`)

```css
:root {
  /* Meridian — Dark */
  --background:        oklch(0.11 0.015 265);   /* Deep blue-black */
  --surface:           oklch(0.165 0.015 265);  /* Card / panel bg */
  --surface-hi:        oklch(0.21 0.015 265);   /* Elevated surface */
  --primary:           oklch(0.76 0.17 72);     /* Saffron gold */
  --primary-dim:       oklch(0.76 0.17 72 / 0.12);
  --primary-glow:      0 8px 32px oklch(0.76 0.17 72 / 0.38);
  --accent:            oklch(0.66 0.14 195);    /* Teal */
  --accent-dim:        oklch(0.66 0.14 195 / 0.12);
  --destructive:       oklch(0.70 0.15 355);    /* Rose/red */
  --foreground:        oklch(0.96 0.005 265);   /* Near white */
  --muted-foreground:  oklch(0.50 0.010 265);   /* Muted text */
  --border:            oklch(1 0 0 / 0.09);     /* Subtle white border */
  --input:             oklch(1 0 0 / 0.09);
  --ring:              oklch(0.76 0.17 72);
  --radius:            0.75rem;
}
```

### Score Colors (semantic)
| State | Color |
|---|---|
| Strong (≥75%) | `oklch(0.65 0.17 145)` — emerald |
| On track (≥50%) | `oklch(0.78 0.17 65)` — amber |
| Needs work (<50%) | `oklch(0.62 0.22 25)` — red |

### Typography
```css
/* In layout.tsx — replace current font imports */
import { DM_Serif_Display, DM_Sans } from "next/font/google";

const dmSerifDisplay = DM_Serif_Display({
  variable: "--font-display",
  weight: "400",
  style: ["normal", "italic"],
  subsets: ["latin"],
});

const dmSans = DM_Sans({
  variable: "--font-sans",
  subsets: ["latin"],
  axes: ["opsz"],
});
```

Font usage:
- **Display / headings:** `font-display` (DM Serif Display) — all `<h1>`, `<h2>`, section headers, stat numbers
- **Body / UI:** `font-sans` (DM Sans) — all body copy, nav links, labels, buttons

### Spacing & Radii
| Token | Value |
|---|---|
| Card border-radius | `18px` (large cards), `12px` (small), `100px` (pills) |
| Page horizontal padding | `72px` desktop, `24px` mobile |
| Section vertical padding | `96px` desktop |
| Nav height | `68px` |
| Card shadow | `0 4px 24px oklch(0 0 0 / 0.32)` |
| Gold glow shadow | `0 8px 32px oklch(0.76 0.17 72 / 0.38)` |

---

## Screens

### 1. Landing Page (`src/app/page.tsx`)

**Layout:** Full-page scroll. Dark background with a fine 64px grid overlay and two radial gradient glows (gold top-right, teal bottom-left).

#### Nav (`src/components/student/student-header.tsx` for logged-in; new `LandingNav` for public)
- `position: fixed`, `height: 68px`, full-width
- **On load:** transparent background, no border
- **On scroll (>40px):** `background: oklch(0.11 0.015 265 / 0.85)`, `backdrop-filter: blur(20px)`, `border-bottom: 1px solid var(--border)` — smooth CSS transition
- Logo: 34×34 gold rounded square with "T" in DM Serif + wordmark "Test*quest*" (italic gold)
- Nav links: 4 anchor links, muted color, hover → foreground
- Right: "Sign in" ghost + "Start free →" gold button with pulse glow animation

#### Hero Section
- `min-height: 100vh`, `padding: 80px 72px 60px`
- **Left column** (max-width 640px):
  - Badge pill: border, background surface, "✦ Built for CBSE…" — animates: `slideUp 0.55s, delay 0ms`
  - H1 (3 lines, `font-size: 80px`, DM Serif Display):
    - Line 1 "The smart way to" — `slideUp 0.65s, delay 100ms`
    - Line 2 "master your" — `slideUp 0.65s, delay 230ms`
    - Line 3 "exams." — `slideUp 0.65s, delay 360ms`, color: `var(--primary)`, italic
  - Subtext: `font-size: 17px`, muted, `line-height: 1.70` — `fadeIn 0.75s, delay 500ms`
  - CTAs: Gold button + ghost button — `slideUp 0.60s, delay 640ms`
  - Avatar row + stars — `fadeIn 0.60s, delay 820ms`
- **Right column** (4 stat cards, flex column, gap 14px):
  - Each card: `background: var(--surface)`, `border: 1px solid var(--border)`, `border-radius: 16px`, `padding: 18px 22px`
  - Cards 0,2 have `margin-left: 0`; cards 1,3 have `margin-left: 32px` (staggered indent)
  - Slide-in animations: `slideInRight 0.65s`, delays: 280ms, 430ms, 580ms, 730ms
  - After slide-in: independent `float` keyframe animations (4.6s, 5.3s, 4.1s, 5.8s durations, different delays) — subtle up/down oscillation of 7–13px

#### CSS Keyframes needed:
```css
@keyframes slideUp   { from { transform: translateY(44px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
@keyframes slideInR  { from { transform: translateX(56px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes fadeIn    { from { opacity: 0; } to { opacity: 1; } }
@keyframes pulse     { 0%,100%{ box-shadow: var(--primary-glow); } 50%{ box-shadow: 0 8px 52px oklch(0.76 0.17 72 / 0.60); } }
@keyframes glow      { 0%,100%{ opacity: 0.09; } 50%{ opacity: 0.17; } }
@keyframes float0    { 0%,100%{ transform: translateY(0px); } 50%{ transform: translateY(-9px); } }
@keyframes float1    { 0%,100%{ transform: translateY(0px); } 50%{ transform: translateY(-11px); } }
@keyframes float2    { 0%,100%{ transform: translateY(0px); } 50%{ transform: translateY(-7px); } }
@keyframes float3    { 0%,100%{ transform: translateY(0px); } 50%{ transform: translateY(-13px); } }
@keyframes ticker    { 0%{ transform: translateX(0); } 100%{ transform: translateX(-50%); } }
@keyframes carouselScroll { 0%{ transform: translateX(0); } 100%{ transform: translateX(-50%); } }
```
All entrance animations should be disabled when `prefers-reduced-motion: reduce`.

#### Subject Ticker
- Full-width strip: `border-top + border-bottom: 1px solid var(--border)`, `background: var(--surface)`, `padding: 14px 0`
- Infinite horizontal marquee: duplicate content twice, animate `translateX(0 → -50%)` at 28s linear infinite
- Pause animation on hover
- Each item: subject name with `✦` bullet, 28px horizontal padding

#### How It Works (3 steps)
- 3-column grid, cards: `background: var(--surface)`, `border-radius: 22px`, `padding: 32px 28px`
- Reveal animation: `opacity: 0 → 1`, `translateY(28px → 0)`, triggered by IntersectionObserver at 18% threshold
- Staggered delays: 100ms, 220ms, 340ms
- Hover: `translateY(-3px)` + deeper shadow

#### Quiz Demo Section (the "Advanced Controller")
2-column grid (1fr 1fr), left = copy, right = interactive quiz card.

**Quiz card:**
- `background: var(--background)`, `border-radius: 24px`, overflow hidden
- **Header:** subject badge + countdown timer ring
- **Timer ring:** SVG circle, `r=22`, circumference ≈ 138px. `stroke-dasharray` = `138 * (timeLeft/30)` — updates every second via `setInterval`. Color: gold >10s, red ≤10s, muted when revealed. `transition: stroke-dasharray 0.9s linear`
- **Options:** 4 buttons, full-width, `border: 1.5px solid var(--border)`, hover → gold border tint
- **After selection:**
  - Correct option: green border + green tint background
  - Wrong selected: red border + red tint
  - Show explanation panel: `background: var(--primary-dim)`, `border-left: 3px solid var(--primary)`
- **Timer runs 30s** → auto-reveals answer if no selection
- "Try again" resets all state

#### Test Card Carousel
- `overflow: hidden`, full-width, no horizontal padding
- Inner track: `display: flex`, duplicate all cards × 2, animate `translateX(0 → -50%)` at 38s linear infinite
- Hover pauses animation
- Fade edge masks: left and right gradient overlays (`linear-gradient` from `var(--background)` to transparent)
- Each card: `width: 300px`, `margin-right: 18px`, `background: var(--surface)`, `border-radius: 18px`
- Card top accent bar: `height: 4px`, color varies by subject (Mathematics→gold, Physics→teal, Chemistry→rose, etc.)
- Hover: `translateY(-4px)` + deeper shadow

#### Stats Counter Section
- 3-column grid in a rounded container
- Numbers count up from 0 using `requestAnimationFrame` with cubic ease-out, triggered by IntersectionObserver
- Targets: 28,000+ · 400+ · 50,000+
- Duration: ~1600–1800ms per counter

#### Pricing Teaser
- 2-column grid: left = copy, right = feature card
- Feature card: `background: var(--surface)`, `border-radius: 22px`, `padding: 32px 28px`
- Two sections separated by border: "Free" items (✓ gold) and "Paid" items (★ gold)

#### Final CTA
- Centered card, `border-radius: 28px`, `background: var(--surface)`
- Radial glow decorations (gold top-right, teal bottom-left)
- Gold button with elevated shadow

---

### 2. Dashboard (`src/app/dashboard/page.tsx`)

**Layout:** Standard top-nav + content. `padding: 40px 72px`.

#### Stat Tiles (4-column grid)
- Cards: `background: var(--surface)`, `border-radius: 16px`, `padding: 20px 22px`
- **Highlighted tile** (Average score): `background: var(--primary)`, text color becomes `var(--background)`, shadow: `var(--primary-glow)`
- Stat value: DM Serif Display, `font-size: 38px`
- Label: `font-size: 12.5px`, muted

#### Recent Attempts (2fr column)
- Container: `background: var(--surface)`, `border-radius: 20px`, overflow hidden
- Row layout: `padding: 13px 24px`, avatar letter + test name + subject·date + score%
- Score colors: ≥75% gold, ≥50% teal, <50% rose
- Avatar: `width: 38px`, `border-radius: 12px`, `background: var(--primary-dim)`, letter in gold

#### Subject Breakdown (1.15fr column) — key improvement
- Mini circle indicator per subject: `width: 42px`, `height: 42px`, `border-radius: 50%`, colored border (`2.5px solid {scoreColor}`) + score number centered
- Progress bar below subject name
- Status label badge: "Strong" / "On track" / "Needs work" — colored pill next to name
- Attempt count in muted text below bar

---

### 3. Tests Browse Page (`src/app/tests/page.tsx`)

**Layout:** Top-nav + content. `padding: 32px 72px`.

#### Filter Bar
- Container: `background: var(--surface)`, `border-radius: 16px`, `padding: 14px 18px`
- Search input: `background: var(--surface-hi)`, `border-radius: 9px`
- Three selects (All classes, All subjects, Free and paid)
- Gold search button with glow shadow

#### Test Card Grid (3-column)
- Card: `background: var(--surface)`, `border-radius: 18px`
- Top accent bar: 4px, color by subject
- Card header: class·subject label + "Free" pill (gold tinted)
- Card title: DM Serif Display, `font-size: 19px`
- Stats row: questions · time · marks (muted)
- "Your best" row: gold tinted background, shows previous best score
- Footer: price/status label + "Start →" / "View →" in gold

---

### 4. Login Page (`src/app/login/page.tsx`)

Keep the existing 2-column split layout. Update:
- Left panel: Use new `var(--surface)` dark background (not `var(--foreground)`)
- Gold accents on left panel headline italic word
- Form inputs: `height: 44px`, border uses new `var(--border)`
- Submit button: gold background with `var(--primary-glow)` shadow
- Logo: updated monogram mark as specified in tokens

---

## Interactions & Behaviour

| Interaction | Spec |
|---|---|
| Nav scroll | Transparent → frosted blur glass at `scrollY > 40px`. Transition: `0.4s ease` |
| Hero entrance | All elements animate in on mount. Stagger via CSS animation-delay. No JS needed. |
| Stat cards float | CSS keyframe float animation, starts after 1.2–2.0s delay |
| Gold button pulse | Glow box-shadow pulsing at `2.8s ease-in-out infinite`. Stop on `prefers-reduced-motion`. |
| Ticker | CSS `animation: ticker 28s linear infinite`. Paused on hover. |
| Carousel | CSS `animation: carouselScroll 38s linear infinite`. Paused on hover. |
| Scroll reveals | `IntersectionObserver` at 18% threshold. Adds `.in` class: `opacity 0→1, translateY 28→0px, transition 0.7s ease`. |
| Quiz timer | `setInterval` every 1000ms. SVG `stroke-dasharray` updates smoothly via CSS `transition: 0.9s linear`. |
| Counter animation | `requestAnimationFrame`, cubic ease-out, triggers once on IntersectionObserver entry. |
| Card hover lift | `transform: translateY(-4px)`, `transition: 0.3s ease` |
| Step card hover | `transform: translateY(-3px)` |

---

## Assets

| Asset | Description |
|---|---|
| Logo mark | SVG "T" in 34×34 gold rounded square. See `src/components/brand/logo.tsx` — update bg to `var(--primary)`, keep existing SVG paths |
| No external image assets | All decorative elements are CSS radial gradients and SVG grid patterns |
| Subject accent colors | Mathematics: gold · Physics: teal · Chemistry: rose · Biology: gold · Science: teal · English: cyan · Economics: lime |

---

## Files in This Bundle

| File | Purpose |
|---|---|
| `Testquest Landing.html` | **Primary reference.** Full animated landing page — all animations, quiz demo, carousel, scroll reveals. |
| `Testquest Revamp.html` | All 3 explored design directions side-by-side (use as comparison reference). Open in browser, click any artboard to go fullscreen. |

---

## Implementation Order (suggested)

1. `globals.css` — add new design tokens, keyframes, utility classes
2. `layout.tsx` — swap fonts to DM Serif Display + DM Sans  
3. `src/components/brand/logo.tsx` — update mark colors
4. `src/components/student/student-header.tsx` — scroll-aware frosted nav
5. `src/app/page.tsx` — landing page (biggest change, start here)
6. `src/app/dashboard/page.tsx` — stat tiles, subject breakdown improvement
7. `src/app/tests/page.tsx` — card grid with accent bars
8. `src/app/login/page.tsx` — minor token updates

---

## Notes for Claude Code

- The quiz demo in `Testquest Landing.html` (`QuizDemo` component, ~80 lines) can be extracted as a standalone `<SampleQuizCard>` component in `src/components/student/` if needed for marketing purposes.
- The infinite carousel and ticker patterns use the "doubled content" technique — render the items array twice side-by-side, animate the container by `-50%`. This avoids any JS scroll tracking.
- All `oklch()` colors are Tailwind CSS v4 compatible — they can go directly in `globals.css` as CSS custom properties and referenced via `var()` or as Tailwind theme tokens.
- Score color thresholds: `pct >= 75` → emerald, `pct >= 50` → amber, `< 50` → red. These are used consistently across dashboard, test cards, and attempt rows.
